import argparse
import shutil
from importlib import resources
from pathlib import Path


def init_repo(target_dir: Path, force: bool = False) -> None:
    """Installs .agent.md, SKILL.md, config, and minimal scripts into a target Git repo."""
    template_root = resources.files("ai_code_secure") / "templates"

    mappings = {
        "config/ai-code-secure.yaml": target_dir / "ai-code-secure.yaml",
        "agents": target_dir / ".ai-code-secure" / "agents",
        "skills": target_dir / ".ai-code-secure" / "skills",
        "ci/.gitlab-ci.ai-secure.yml": target_dir / ".gitlab-ci.ai-secure.yml",
    }

    for src_rel, dst in mappings.items():
        src = template_root / src_rel
        if dst.exists() and not force:
            raise FileExistsError(f"{dst} already exists. Use --force to overwrite.")
        if dst.exists() and force:
            if dst.is_dir():
                shutil.rmtree(dst)
            else:
                dst.unlink()

        if src.is_dir():
            shutil.copytree(src, dst)
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)


def main() -> None:
    parser = argparse.ArgumentParser(prog="ai-code-secure", description="AI Code Secure Setup CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init", help="Install agent & skill definitions into a repository")
    init_parser.add_argument("--path", type=Path, default=Path.cwd(), help="Target repository path")
    init_parser.add_argument("--force", action="store_true", help="Overwrite existing configuration")

    args = parser.parse_args()
    if args.command == "init":
        init_repo(args.path.resolve(), force=args.force)
        print(f"AI Code Secure initialized in {args.path.resolve()}")